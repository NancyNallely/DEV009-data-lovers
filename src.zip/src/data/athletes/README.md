# Juegos Olímpicos de Río de Janeiro

Juegos Olímpicos de Río de Janeiro, fueron un evento multideportivo internacional,
celebrado en la ciudad de Río de Janeiro, Brasil. La elección de Río marcó la
primera vez que se realiza en un país sudamericano. Este evento tuvo gran
acogida a nivel mundial, de todas estas personas hay un grupo que desea poder
interactuar y ver la información de los atletas, los deportes olímpicos y los
países que participaron.

## Hallazgos

Para entender mejor qué información que podrían necesitar nuestos usuarios,
hicimos una rápida investigación (research) y estos son algunos de los
hallazgos.

- Información relevante sobre los atletas olímpicos, como nombre, altura, peso,
país que representa y especialidad deportiva
- En los juegos olímpicos son muchos los países participantes, para nuestros
usuarios es importante saber cuáles son
- Adicionalmente a esta información, para nuestros usuarios es importante poder
ver la cantidad de atletas que participaron por país
- En los juegos olímpicos hay deportes y estos tienen sus disciplinas, para
nuestros usuarios es importante saber cuántos y cuáles son
- En los juegos olímpicos siempre hay equipos o atletas que ganan diferentes
disciplinas, para nuestros usuarios es importante saber quiénes son y cuantas
son las medallas que ganaron
- Adicionalmente a nuestros usuarios les gustaría saber la cantidad de mujeres
atletas que participaron y ganaron medallas.
