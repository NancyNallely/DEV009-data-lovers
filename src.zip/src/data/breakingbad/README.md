# Breaking Bad

Breaking Bad es una serie de televisión estadounidense
creada y producida por Vince Gilligan. Situada y producida
en Albuquerque, Nuevo México, consiste en la historia de
Walter White, un profesor de química al que diagnostican
un cáncer de pulmón inoperable. Walter pasa a una vida de
crimen produciendo y distribuyendo metanfetamina junto
a un ex-estudiante, Jesse Pinkman, con el objetivo de
conseguir suficiente dinero para el futuro de su
familia tras su inevitable muerte

## Hallazgos

Haciendo una investigación (research) sobre la
información que podrían necesitar nuestras
usuarias encontramos que los datos de mayor
interés son:

- Información sobre los personajes como nombre,
apodo, ocupación y nombre de la actriz o actor
que lo interpreta.

- Adicionalmente a esta información, Breaking Bad
coexsiste con Better Call Saul; para nuestras usuarias
es importante poder ver la lista de personajes que
aparecen cada una de las series.

## Detalles de la data

Con este set de datos puedes obtener los siguientes datos de un personaje:

- nombre
- imagen
- ocupación
- estado de vida
- apodo/nickname
- categoria
- temporada donde aparece
