# Game of Thrones

"Juego de Tronos" es una serie de televisión de drama y
fantasía épica creada por David Benioff y D.B. Weiss,
basada en la serie de novelas "Canción de Hielo y Fuego"
del autor George R.R. Martin. La serie sigue las luchas y
conflictos entre varias casas nobles en el ficticio continente
de Westeros, mientras compiten por el Trono de Hierro y el
control de los Siete Reinos.

## Hallazgos

Haciendo una investigación (research) sobre la
información que podrían necesitar nuestras
usuarias encontramos que los datos de mayor
interés son:

- Información sobre los personajes como nombre,
titulo, imagen y famila

Adicionalmente a esta información, para nuestras usuarias es importante poder
ver la lista de personajes que aparecen en
la serie y la cantidad de miembros en cada familia para
tener mayor información de la serie.

## Detalles de la data

- nombre
- apellido
- titulo
- familia
- imagen
- año de nacimiento
- año de muerte
